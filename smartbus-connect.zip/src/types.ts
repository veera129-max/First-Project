export type ScreenType = 'home' | 'departure' | 'tracking' | 'signin' | 'bookings' | 'schedules';

export interface BusRoute {
  id: string;
  operator: string;
  type: string;
  features: string[];
  departureTime: string;
  arrivalTime: string;
  origin: string;
  originStation: string;
  destination: string;
  destinationStation: string;
  duration: string;
  status: 'On Time' | 'Fastest' | 'Delayed' | 'Direct';
  price: number;
}

export type SeatStatus = 'available' | 'occupied' | 'selected';

export interface Seat {
  id: string;
  status: SeatStatus;
}

export interface Booking {
  pnr: string;
  routeName: string;
  date: string;
  departureTime: string;
  arrivalTime: string;
  origin: string;
  destination: string;
  seat: string;
  passengerName: string;
  ticketPrice: number;
  seatFee: number;
  taxes: number;
  totalFare: number;
  status: 'Confirmed' | 'Boarded' | 'Completed';
  qrCodeUrl: string;
}

export interface FleetVehicle {
  id: string;
  number: string;
  route: string;
  origin: string;
  destination: string;
  type: string;
  driverName: string;
  driverId: string;
  status: 'On Time' | 'Delayed' | 'Maintenance';
  speed: number;
  estArrival: string;
  latPct: number; // For map marker positioning 0-100%
  lngPct: number;
  inTransit: boolean;
  passengerLoad: string;
  fuelBattery: string;
}
