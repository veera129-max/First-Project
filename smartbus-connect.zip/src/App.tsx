import React, { useState } from 'react';
import { ScreenType, Booking, BusRoute } from './types';
import { INITIAL_BOOKINGS } from './data/mockData';
import { TopNavBar } from './components/TopNavBar';
import { HomeScreen } from './components/HomeScreen';
import { BookingScreen } from './components/BookingScreen';
import { TrackingScreen } from './components/TrackingScreen';
import { SignInScreen } from './components/SignInScreen';
import { MyBookingsScreen } from './components/MyBookingsScreen';
import { SchedulesScreen } from './components/SchedulesScreen';
import { CheckCircle2, X } from 'lucide-react';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<ScreenType>('departure');
  const [userRole, setUserRole] = useState<'admin' | 'passenger' | null>(null);
  const [searchQuery, setSearchQuery] = useState({
    source: 'New York (NYC)',
    destination: 'Boston (BOS)',
    date: '2024-10-24',
  });
  const [bookings, setBookings] = useState<Booking[]>(INITIAL_BOOKINGS);
  const [successToast, setSuccessToast] = useState<string | null>(null);

  const handleSearch = (source: string, destination: string, date: string) => {
    setSearchQuery({ source, destination, date });
    setCurrentScreen('departure');
  };

  const handleBookingComplete = (newBooking: Booking) => {
    setBookings([newBooking, ...bookings]);
    setSuccessToast(`Reservation confirmed! PNR: ${newBooking.pnr} issued for Seat ${newBooking.seat}`);
    setTimeout(() => {
      setCurrentScreen('bookings');
    }, 1000);
    setTimeout(() => {
      setSuccessToast(null);
    }, 6000);
  };

  const handleLoginSuccess = (role: 'admin' | 'passenger') => {
    setUserRole(role);
    if (role === 'admin') {
      setCurrentScreen('tracking');
    } else {
      setCurrentScreen('departure');
    }
  };

  const handleSignOut = () => {
    setUserRole(null);
    setCurrentScreen('home');
  };

  const handleSelectRouteForBooking = (route: BusRoute) => {
    setSearchQuery({
      source: route.originStation,
      destination: route.destinationStation,
      date: '2024-10-24',
    });
  };

  return (
    <div className="min-h-screen bg-[#f8f9ff] text-[#0b1c30] flex flex-col font-sans">
      {/* Toast Notification */}
      {successToast && (
        <div className="fixed bottom-6 right-6 z-50 bg-[#00288e] text-white px-5 py-3.5 rounded-xl shadow-2xl flex items-center gap-3 border border-[#6ffbbe]/40 animate-in slide-in-from-bottom-5">
          <CheckCircle2 className="w-5 h-5 text-[#6ffbbe]" />
          <span className="text-xs sm:text-sm font-semibold">{successToast}</span>
          <button
            onClick={() => setSuccessToast(null)}
            className="ml-2 text-[#a8b8ff] hover:text-white p-1"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Public / Passenger Top Navigation Bar (Hidden when in full Admin Tracking mode or Sign-In screen) */}
      {currentScreen !== 'tracking' && currentScreen !== 'signin' && (
        <TopNavBar
          currentScreen={currentScreen}
          onNavigate={setCurrentScreen}
          userRole={userRole}
          onSignOut={handleSignOut}
        />
      )}

      {/* Screen Routing */}
      {currentScreen === 'home' && (
        <HomeScreen
          onSearch={handleSearch}
          onOpenPortal={() => setCurrentScreen('tracking')}
        />
      )}

      {currentScreen === 'departure' && (
        <BookingScreen
          searchQuery={searchQuery}
          onBookingComplete={handleBookingComplete}
        />
      )}

      {currentScreen === 'tracking' && (
        <TrackingScreen
          onNavigate={setCurrentScreen}
          onLogout={() => {
            setUserRole(null);
            setCurrentScreen('home');
          }}
        />
      )}

      {currentScreen === 'signin' && (
        <SignInScreen
          onLoginSuccess={handleLoginSuccess}
          onNavigate={setCurrentScreen}
        />
      )}

      {currentScreen === 'bookings' && (
        <MyBookingsScreen
          bookings={bookings}
          onNavigate={setCurrentScreen}
        />
      )}

      {currentScreen === 'schedules' && (
        <SchedulesScreen
          onSelectRouteForBooking={handleSelectRouteForBooking}
          onNavigate={setCurrentScreen}
        />
      )}
    </div>
  );
}
