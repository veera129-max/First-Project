import React, { useState } from 'react';
import { ScreenType } from '../types';
import { Menu, X, Bus, User, ShieldCheck } from 'lucide-react';

interface TopNavBarProps {
  currentScreen: ScreenType;
  onNavigate: (screen: ScreenType) => void;
  userRole?: 'admin' | 'passenger' | null;
  onSignOut?: () => void;
}

export const TopNavBar: React.FC<TopNavBarProps> = ({
  currentScreen,
  onNavigate,
  userRole,
  onSignOut
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <nav id="top-nav-bar" className="fixed top-0 w-full z-50 bg-[#f8f9ff]/95 backdrop-blur-md shadow-sm border-b border-[#c4c5d5]/30">
      <div className="flex justify-between items-center h-16 px-4 sm:px-6 max-w-7xl mx-auto">
        {/* Brand */}
        <div 
          onClick={() => onNavigate('home')}
          className="flex items-center gap-3 cursor-pointer select-none group"
        >
          <div className="w-9 h-9 rounded-lg bg-[#00288e] flex items-center justify-center text-white shadow-sm transition-transform group-hover:scale-105">
            <Bus className="w-5 h-5" />
          </div>
          <span className="text-[22px] font-bold tracking-tight text-[#00288e]">
            SmartBus Connect
          </span>
        </div>

        {/* Desktop Nav Items */}
        <div className="hidden md:flex gap-8 items-center">
          <button
            id="nav-find-routes"
            onClick={() => onNavigate('departure')}
            className={`text-sm font-semibold transition-colors pb-1 ${
              currentScreen === 'departure' || currentScreen === 'home'
                ? 'text-[#00288e] border-b-2 border-[#00288e]'
                : 'text-[#444653] hover:text-[#00288e]'
            }`}
          >
            Find Routes
          </button>
          <button
            id="nav-my-bookings"
            onClick={() => onNavigate('bookings')}
            className={`text-sm font-semibold transition-colors pb-1 ${
              currentScreen === 'bookings'
                ? 'text-[#00288e] border-b-2 border-[#00288e]'
                : 'text-[#444653] hover:text-[#00288e]'
            }`}
          >
            My Bookings
          </button>
          <button
            id="nav-schedules"
            onClick={() => onNavigate('schedules')}
            className={`text-sm font-semibold transition-colors pb-1 ${
              currentScreen === 'schedules'
                ? 'text-[#00288e] border-b-2 border-[#00288e]'
                : 'text-[#444653] hover:text-[#00288e]'
            }`}
          >
            Schedules
          </button>
          <button
            id="nav-support"
            onClick={() => {
              alert('SmartBus Connect Support: 24/7 hotline 1-800-SMARTBUS or email support@smartbus.com');
            }}
            className="text-sm font-semibold text-[#444653] hover:text-[#00288e] transition-colors pb-1"
          >
            Support
          </button>
        </div>

        {/* Desktop Action Buttons */}
        <div className="hidden md:flex items-center gap-3">
          <button
            id="btn-operator-portal"
            onClick={() => onNavigate('tracking')}
            className={`text-sm font-semibold px-3.5 py-2 rounded-lg transition-all flex items-center gap-1.5 ${
              currentScreen === 'tracking'
                ? 'bg-[#1e40af] text-white shadow-sm'
                : 'text-[#444653] hover:text-[#00288e] hover:bg-[#eff4ff]'
            }`}
          >
            <ShieldCheck className="w-4 h-4 text-[#006c49]" />
            Operator Portal
          </button>

          {userRole ? (
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-2 px-3 py-1.5 bg-[#eff4ff] border border-[#c4c5d5]/50 rounded-lg text-xs font-semibold text-[#00288e]">
                <User className="w-3.5 h-3.5" />
                <span>{userRole === 'admin' ? 'Admin Controller' : 'Passenger'}</span>
              </div>
              <button
                onClick={onSignOut}
                className="text-xs text-[#757684] hover:text-[#ba1a1a] transition-colors px-2 py-1"
              >
                Sign Out
              </button>
            </div>
          ) : (
            <button
              id="btn-signin"
              onClick={() => onNavigate('signin')}
              className="bg-[#00288e] text-white text-sm font-semibold px-4 py-2 rounded-lg hover:bg-[#00288e]/90 transition-all shadow-sm active:scale-95"
            >
              Sign In
            </button>
          )}
        </div>

        {/* Mobile Hamburger Button */}
        <div className="md:hidden flex items-center gap-2">
          <button
            onClick={() => onNavigate('tracking')}
            className="text-xs bg-[#1e40af] text-white px-2.5 py-1.5 rounded font-medium"
          >
            Portal
          </button>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-[#0b1c30] rounded-lg hover:bg-[#eff4ff]"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#ffffff] border-b border-[#c4c5d5] px-6 py-4 space-y-3 shadow-lg">
          <button
            onClick={() => { onNavigate('departure'); setMobileMenuOpen(false); }}
            className="block w-full text-left py-2 font-medium text-[#0b1c30]"
          >
            Find Routes & Book
          </button>
          <button
            onClick={() => { onNavigate('bookings'); setMobileMenuOpen(false); }}
            className="block w-full text-left py-2 font-medium text-[#0b1c30]"
          >
            My Bookings
          </button>
          <button
            onClick={() => { onNavigate('schedules'); setMobileMenuOpen(false); }}
            className="block w-full text-left py-2 font-medium text-[#0b1c30]"
          >
            Schedules
          </button>
          <button
            onClick={() => { onNavigate('tracking'); setMobileMenuOpen(false); }}
            className="block w-full text-left py-2 font-medium text-[#006c49]"
          >
            Live Fleet Monitor (Admin)
          </button>
          <button
            onClick={() => { onNavigate('signin'); setMobileMenuOpen(false); }}
            className="w-full bg-[#00288e] text-white py-2 rounded-lg font-medium text-center mt-2"
          >
            {userRole ? 'Sign In / Switch' : 'Sign In'}
          </button>
        </div>
      )}
    </nav>
  );
};
