import React, { useState } from 'react';
import { BusRoute, ScreenType } from '../types';
import { INITIAL_ROUTES } from '../data/mockData';
import { Calendar, Search, ArrowRight, Bus, Clock, ShieldCheck } from 'lucide-react';

interface SchedulesScreenProps {
  onSelectRouteForBooking: (route: BusRoute) => void;
  onNavigate: (screen: ScreenType) => void;
}

export const SchedulesScreen: React.FC<SchedulesScreenProps> = ({
  onSelectRouteForBooking,
  onNavigate,
}) => {
  const [filterCorridor, setFilterCorridor] = useState<string>('all');
  const [routes] = useState<BusRoute[]>(INITIAL_ROUTES);

  return (
    <div className="pt-20 pb-20 max-w-7xl mx-auto px-4 sm:px-6">
      <div className="mb-8">
        <h1 className="text-2xl sm:text-3xl font-bold text-[#0b1c30]">
          Timetables &amp; Corridor Schedules
        </h1>
        <p className="text-sm text-[#444653] mt-1">
          High-frequency departures with live on-time tracking and GPS verification.
        </p>
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-3 mb-6">
        {[
          { id: 'all', label: 'All Corridors' },
          { id: 'nyc-bos', label: 'New York (NYC) ↔ Boston (BOS)' },
          { id: 'nyc-dc', label: 'New York (NYC) ↔ Washington (DC)' },
          { id: 'chi-det', label: 'Chicago (CHI) ↔ Detroit (DET)' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setFilterCorridor(tab.id)}
            className={`px-4 py-2 rounded-lg text-xs sm:text-sm font-semibold whitespace-nowrap transition-colors ${
              filterCorridor === tab.id
                ? 'bg-[#00288e] text-white shadow-sm'
                : 'bg-white text-[#444653] border border-[#c4c5d5] hover:bg-[#eff4ff]'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Timetable Table */}
      <div className="bg-white rounded-2xl border border-[#c4c5d5] shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-[#eff4ff] border-b border-[#c4c5d5] text-xs font-semibold text-[#00288e] uppercase tracking-wider">
                <th className="py-3.5 px-6">Departure</th>
                <th className="py-3.5 px-6">Arrival</th>
                <th className="py-3.5 px-6">Route / Service</th>
                <th className="py-3.5 px-6">Duration</th>
                <th className="py-3.5 px-6">Status</th>
                <th className="py-3.5 px-6">Fare</th>
                <th className="py-3.5 px-6 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#c4c5d5]/40 text-sm">
              {routes.map((r) => (
                <tr key={r.id} className="hover:bg-[#f8f9ff] transition-colors">
                  <td className="py-4 px-6 font-bold text-[#0b1c30]">
                    {r.departureTime}
                    <span className="block text-xs font-normal text-[#757684]">
                      {r.originStation}
                    </span>
                  </td>
                  <td className="py-4 px-6 font-bold text-[#0b1c30]">
                    {r.arrivalTime}
                    <span className="block text-xs font-normal text-[#757684]">
                      {r.destinationStation}
                    </span>
                  </td>
                  <td className="py-4 px-6">
                    <div className="flex items-center gap-2">
                      <Bus className="w-4 h-4 text-[#00288e]" />
                      <span className="font-semibold text-[#0b1c30]">{r.operator}</span>
                    </div>
                    <span className="text-xs text-[#757684]">{r.features.join(' • ')}</span>
                  </td>
                  <td className="py-4 px-6 text-[#444653]">
                    {r.duration}
                  </td>
                  <td className="py-4 px-6">
                    <span className="px-2.5 py-1 rounded-full bg-[#006c49]/10 text-[#006c49] text-xs font-semibold">
                      {r.status}
                    </span>
                  </td>
                  <td className="py-4 px-6 font-bold text-[#00288e]">
                    ${r.price.toFixed(2)}
                  </td>
                  <td className="py-4 px-6 text-right">
                    <button
                      onClick={() => {
                        onSelectRouteForBooking(r);
                        onNavigate('departure');
                      }}
                      className="bg-[#00288e] text-white text-xs font-semibold px-3.5 py-2 rounded-lg hover:bg-[#00288e]/90 transition-colors inline-flex items-center gap-1"
                    >
                      Book
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
