import React, { useState } from 'react';
import { BusRoute, Seat } from '../types';
import { INITIAL_ROUTES, INITIAL_SEATS, QR_CODE_IMAGE } from '../data/mockData';
import { Bus, Ticket, Check, Sparkles, ArrowRight, X } from 'lucide-react';

interface BookingScreenProps {
  searchQuery: {
    source: string;
    destination: string;
    date: string;
  };
  onBookingComplete: (bookingData: any) => void;
}

export const BookingScreen: React.FC<BookingScreenProps> = ({
  searchQuery,
  onBookingComplete,
}) => {
  const [routes] = useState<BusRoute[]>(INITIAL_ROUTES);
  const [selectedRouteId, setSelectedRouteId] = useState<string>('route-2');
  const [seats, setSeats] = useState<Seat[]>(INITIAL_SEATS);
  const [selectedSeat, setSelectedSeat] = useState<string>('2A');
  const [showCheckoutModal, setShowCheckoutModal] = useState<boolean>(false);
  const [passengerName, setPassengerName] = useState<string>('Alex Morgan');
  const [passengerEmail, setPassengerEmail] = useState<string>('alex.morgan@example.com');
  const [passengerPhone, setPassengerPhone] = useState<string>('+1 (555) 234-5678');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  const currentRoute = routes.find((r) => r.id === selectedRouteId) || routes[1];
  const ticketBasePrice = currentRoute.price;
  const seatFee = selectedSeat.startsWith('1') ? 5.0 : 0.0;
  const taxesAndFees = 4.5;
  const totalFare = ticketBasePrice + seatFee + taxesAndFees;

  const handleSeatClick = (seatId: string) => {
    const seat = seats.find((s) => s.id === seatId);
    if (!seat || seat.status === 'occupied') return;

    setSelectedSeat(seatId);
    setSeats((prev) =>
      prev.map((s) => {
        if (s.status === 'occupied') return s;
        if (s.id === seatId) return { ...s, status: 'selected' };
        return { ...s, status: 'available' };
      })
    );
  };

  const handleConfirmPayment = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setShowCheckoutModal(false);
      const newBooking = {
        pnr: `SBC-${Math.random().toString(36).substring(2, 7).toUpperCase()}`,
        routeName: currentRoute.operator,
        date: searchQuery.date || 'Oct 24, 2024',
        departureTime: currentRoute.departureTime,
        arrivalTime: currentRoute.arrivalTime,
        origin: currentRoute.originStation,
        destination: currentRoute.destinationStation,
        seat: selectedSeat,
        passengerName,
        ticketPrice: ticketBasePrice,
        seatFee,
        taxes: taxesAndFees,
        totalFare,
        status: 'Confirmed' as const,
        qrCodeUrl: QR_CODE_IMAGE,
      };
      onBookingComplete(newBooking);
    }, 1200);
  };

  return (
    <div className="pt-20 pb-20 max-w-7xl mx-auto px-4 sm:px-6">
      {/* Top Header */}
      <div className="mb-8">
        <h1 className="text-2xl sm:text-3xl font-bold text-[#0b1c30] tracking-tight">
          Select Departure
        </h1>
        <p className="text-sm sm:text-base text-[#444653] mt-2">
          {searchQuery.source || 'New York (NYC)'} to {searchQuery.destination || 'Boston (BOS)'} • {searchQuery.date || 'Oct 24, 2024'}
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Main Content Area (8 Columns) */}
        <div className="lg:col-span-8 flex flex-col gap-6">
          {/* Available Routes List */}
          <div className="flex flex-col gap-4">
            <h2 className="text-xl sm:text-2xl font-bold text-[#0b1c30]">
              Available Routes
            </h2>

            {routes.map((route) => {
              const isSelected = selectedRouteId === route.id;
              return (
                <div
                  key={route.id}
                  id={`route-card-${route.id}`}
                  className={`rounded-xl p-5 sm:p-6 transition-all relative ${
                    isSelected
                      ? 'bg-[#eff4ff] border-2 border-[#00288e] shadow-md'
                      : 'bg-[#ffffff] border border-[#c4c5d5] shadow-sm hover:shadow-md'
                  }`}
                >
                  {/* Selected Badge */}
                  {isSelected && (
                    <div className="absolute top-0 right-0 bg-[#00288e] text-white text-xs font-semibold px-3 py-1 rounded-bl-lg rounded-tr-lg">
                      Selected
                    </div>
                  )}

                  <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                    {/* Operator info */}
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-[#e5eeff] rounded-lg flex items-center justify-center text-[#00288e] shrink-0">
                        <Bus className="w-6 h-6" />
                      </div>
                      <div>
                        <h3 className="text-sm sm:text-base font-semibold text-[#0b1c30]">
                          {route.operator}
                        </h3>
                        <p className="text-xs sm:text-sm text-[#444653]">
                          {route.features.join(' • ')}
                        </p>
                      </div>
                    </div>

                    {/* Times & Duration Timeline */}
                    <div className="flex items-center gap-4 sm:gap-6 my-2 md:my-0">
                      <div className="text-right">
                        <div className="text-lg sm:text-xl font-bold text-[#0b1c30]">
                          {route.departureTime}
                        </div>
                        <div className="text-xs text-[#444653]">
                          {route.originStation}
                        </div>
                      </div>

                      <div className="flex flex-col items-center px-2 sm:px-4">
                        <span className="text-xs text-[#444653]">
                          {route.duration}
                        </span>
                        <div className="w-20 sm:w-24 h-px bg-[#c4c5d5] relative my-1.5">
                          <div className="absolute w-2 h-2 rounded-full bg-[#757684] -left-1 -top-[3.5px]"></div>
                          <div className="absolute w-2 h-2 rounded-full bg-[#757684] -right-1 -top-[3.5px]"></div>
                        </div>
                        <span className="text-xs font-semibold text-[#006c49]">
                          {route.status}
                        </span>
                      </div>

                      <div className="text-left">
                        <div className="text-lg sm:text-xl font-bold text-[#0b1c30]">
                          {route.arrivalTime}
                        </div>
                        <div className="text-xs text-[#444653]">
                          {route.destinationStation}
                        </div>
                      </div>
                    </div>

                    {/* Price and Select/Change CTA */}
                    <div className="flex flex-row md:flex-col items-center md:items-end justify-between w-full md:w-auto gap-2 border-t md:border-t-0 md:border-l border-[#c4c5d5] pt-3 md:pt-0 md:pl-6">
                      <div className="text-xl sm:text-2xl font-bold text-[#00288e]">
                        ${route.price.toFixed(2)}
                      </div>
                      {isSelected ? (
                        <button
                          onClick={() => setSelectedRouteId(route.id)}
                          className="bg-[#f8f9ff] text-[#00288e] border border-[#00288e] text-sm font-semibold px-4 py-2 rounded-lg hover:bg-[#e5eeff] transition-colors"
                        >
                          Change
                        </button>
                      ) : (
                        <button
                          onClick={() => setSelectedRouteId(route.id)}
                          className="bg-[#00288e] text-white text-sm font-semibold px-4 py-2 rounded-lg hover:bg-[#00288e]/90 transition-colors"
                        >
                          Select Seats
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Seat Selection Interface */}
          <div className="bg-[#ffffff] border border-[#c4c5d5] rounded-xl p-6 shadow-sm mt-4">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6 border-b border-[#c4c5d5] pb-4">
              <div>
                <h2 className="text-xl font-bold text-[#0b1c30]">
                  Select Your Seat
                </h2>
                <p className="text-xs text-[#444653] mt-0.5">
                  Selected Seat: <span className="font-bold text-[#00288e]">{selectedSeat}</span>
                </p>
              </div>

              {/* Seat Legend */}
              <div className="flex gap-4">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded bg-[#e5eeff] border border-[#c4c5d5]"></div>
                  <span className="text-xs text-[#444653]">Available</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded bg-[#c4c5d5]"></div>
                  <span className="text-xs text-[#444653]">Occupied</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded bg-[#00288e]"></div>
                  <span className="text-xs text-[#444653]">Selected</span>
                </div>
              </div>
            </div>

            {/* Bus Cabin Graphic Container */}
            <div className="flex justify-center py-4">
              <div className="bg-[#eff4ff] rounded-[40px] p-8 border-2 border-[#c4c5d5] w-full max-w-sm relative shadow-inner">
                {/* Driver Area Indicator */}
                <div className="absolute top-4 right-8 w-9 h-9 rounded-full border-2 border-[#757684] flex items-center justify-center text-[#757684]" title="Driver Steering Area">
                  <span className="material-symbols-outlined text-sm">swipe_left_alt</span>
                </div>
                <div className="absolute top-5 left-8 text-xs font-semibold uppercase tracking-wider text-[#757684]">
                  FRONT
                </div>

                {/* Rows Grid */}
                <div className="mt-12 flex flex-col gap-4">
                  {/* Row 1 */}
                  <div className="flex justify-between">
                    <div className="flex gap-2">
                      {['1A', '1B'].map((seatId) => {
                        const s = seats.find((x) => x.id === seatId);
                        const isOcc = s?.status === 'occupied';
                        const isSel = selectedSeat === seatId;
                        return (
                          <button
                            key={seatId}
                            id={`seat-${seatId}`}
                            disabled={isOcc}
                            onClick={() => handleSeatClick(seatId)}
                            className={`w-10 h-12 rounded-t-lg rounded-b-sm font-semibold text-xs transition-all flex items-center justify-center ${
                              isSel
                                ? 'bg-[#00288e] text-white shadow-md scale-105 ring-2 ring-[#00288e]'
                                : isOcc
                                ? 'bg-[#c4c5d5] text-[#757684] cursor-not-allowed'
                                : 'bg-[#e5eeff] text-[#0b1c30] border border-[#c4c5d5] hover:border-[#00288e] hover:bg-[#dce9ff]'
                            }`}
                          >
                            {seatId}
                          </button>
                        );
                      })}
                    </div>
                    <div className="w-8 flex items-center justify-center text-[10px] text-[#757684] tracking-widest font-mono">
                      AISLE
                    </div>
                    <div className="flex gap-2">
                      {['1C', '1D'].map((seatId) => {
                        const s = seats.find((x) => x.id === seatId);
                        const isOcc = s?.status === 'occupied';
                        const isSel = selectedSeat === seatId;
                        return (
                          <button
                            key={seatId}
                            id={`seat-${seatId}`}
                            disabled={isOcc}
                            onClick={() => handleSeatClick(seatId)}
                            className={`w-10 h-12 rounded-t-lg rounded-b-sm font-semibold text-xs transition-all flex items-center justify-center ${
                              isSel
                                ? 'bg-[#00288e] text-white shadow-md scale-105 ring-2 ring-[#00288e]'
                                : isOcc
                                ? 'bg-[#c4c5d5] text-[#757684] cursor-not-allowed'
                                : 'bg-[#e5eeff] text-[#0b1c30] border border-[#c4c5d5] hover:border-[#00288e] hover:bg-[#dce9ff]'
                            }`}
                          >
                            {seatId}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Row 2 */}
                  <div className="flex justify-between">
                    <div className="flex gap-2">
                      {['2A', '2B'].map((seatId) => {
                        const s = seats.find((x) => x.id === seatId);
                        const isOcc = s?.status === 'occupied';
                        const isSel = selectedSeat === seatId;
                        return (
                          <button
                            key={seatId}
                            id={`seat-${seatId}`}
                            disabled={isOcc}
                            onClick={() => handleSeatClick(seatId)}
                            className={`w-10 h-12 rounded-t-lg rounded-b-sm font-semibold text-xs transition-all flex items-center justify-center ${
                              isSel
                                ? 'bg-[#00288e] text-white shadow-md scale-105 ring-2 ring-[#00288e]'
                                : isOcc
                                ? 'bg-[#c4c5d5] text-[#757684] cursor-not-allowed'
                                : 'bg-[#e5eeff] text-[#0b1c30] border border-[#c4c5d5] hover:border-[#00288e] hover:bg-[#dce9ff]'
                            }`}
                          >
                            {seatId}
                          </button>
                        );
                      })}
                    </div>
                    <div className="w-8"></div>
                    <div className="flex gap-2">
                      {['2C', '2D'].map((seatId) => {
                        const s = seats.find((x) => x.id === seatId);
                        const isOcc = s?.status === 'occupied';
                        const isSel = selectedSeat === seatId;
                        return (
                          <button
                            key={seatId}
                            id={`seat-${seatId}`}
                            disabled={isOcc}
                            onClick={() => handleSeatClick(seatId)}
                            className={`w-10 h-12 rounded-t-lg rounded-b-sm font-semibold text-xs transition-all flex items-center justify-center ${
                              isSel
                                ? 'bg-[#00288e] text-white shadow-md scale-105 ring-2 ring-[#00288e]'
                                : isOcc
                                ? 'bg-[#c4c5d5] text-[#757684] cursor-not-allowed'
                                : 'bg-[#e5eeff] text-[#0b1c30] border border-[#c4c5d5] hover:border-[#00288e] hover:bg-[#dce9ff]'
                            }`}
                          >
                            {seatId}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Row 3 */}
                  <div className="flex justify-between">
                    <div className="flex gap-2">
                      {['3A', '3B'].map((seatId) => {
                        const s = seats.find((x) => x.id === seatId);
                        const isOcc = s?.status === 'occupied';
                        const isSel = selectedSeat === seatId;
                        return (
                          <button
                            key={seatId}
                            id={`seat-${seatId}`}
                            disabled={isOcc}
                            onClick={() => handleSeatClick(seatId)}
                            className={`w-10 h-12 rounded-t-lg rounded-b-sm font-semibold text-xs transition-all flex items-center justify-center ${
                              isSel
                                ? 'bg-[#00288e] text-white shadow-md scale-105 ring-2 ring-[#00288e]'
                                : isOcc
                                ? 'bg-[#c4c5d5] text-[#757684] cursor-not-allowed'
                                : 'bg-[#e5eeff] text-[#0b1c30] border border-[#c4c5d5] hover:border-[#00288e] hover:bg-[#dce9ff]'
                            }`}
                          >
                            {seatId}
                          </button>
                        );
                      })}
                    </div>
                    <div className="w-8"></div>
                    <div className="flex gap-2">
                      {['3C', '3D'].map((seatId) => {
                        const s = seats.find((x) => x.id === seatId);
                        const isOcc = s?.status === 'occupied';
                        const isSel = selectedSeat === seatId;
                        return (
                          <button
                            key={seatId}
                            id={`seat-${seatId}`}
                            disabled={isOcc}
                            onClick={() => handleSeatClick(seatId)}
                            className={`w-10 h-12 rounded-t-lg rounded-b-sm font-semibold text-xs transition-all flex items-center justify-center ${
                              isSel
                                ? 'bg-[#00288e] text-white shadow-md scale-105 ring-2 ring-[#00288e]'
                                : isOcc
                                ? 'bg-[#c4c5d5] text-[#757684] cursor-not-allowed'
                                : 'bg-[#e5eeff] text-[#0b1c30] border border-[#c4c5d5] hover:border-[#00288e] hover:bg-[#dce9ff]'
                            }`}
                          >
                            {seatId}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Row 4 */}
                  <div className="flex justify-between">
                    <div className="flex gap-2">
                      {['4A', '4B'].map((seatId) => {
                        const s = seats.find((x) => x.id === seatId);
                        const isOcc = s?.status === 'occupied';
                        const isSel = selectedSeat === seatId;
                        return (
                          <button
                            key={seatId}
                            id={`seat-${seatId}`}
                            disabled={isOcc}
                            onClick={() => handleSeatClick(seatId)}
                            className={`w-10 h-12 rounded-t-lg rounded-b-sm font-semibold text-xs transition-all flex items-center justify-center ${
                              isSel
                                ? 'bg-[#00288e] text-white shadow-md scale-105 ring-2 ring-[#00288e]'
                                : isOcc
                                ? 'bg-[#c4c5d5] text-[#757684] cursor-not-allowed'
                                : 'bg-[#e5eeff] text-[#0b1c30] border border-[#c4c5d5] hover:border-[#00288e] hover:bg-[#dce9ff]'
                            }`}
                          >
                            {seatId}
                          </button>
                        );
                      })}
                    </div>
                    <div className="w-8"></div>
                    <div className="flex gap-2">
                      {['4C', '4D'].map((seatId) => {
                        const s = seats.find((x) => x.id === seatId);
                        const isOcc = s?.status === 'occupied';
                        const isSel = selectedSeat === seatId;
                        return (
                          <button
                            key={seatId}
                            id={`seat-${seatId}`}
                            disabled={isOcc}
                            onClick={() => handleSeatClick(seatId)}
                            className={`w-10 h-12 rounded-t-lg rounded-b-sm font-semibold text-xs transition-all flex items-center justify-center ${
                              isSel
                                ? 'bg-[#00288e] text-white shadow-md scale-105 ring-2 ring-[#00288e]'
                                : isOcc
                                ? 'bg-[#c4c5d5] text-[#757684] cursor-not-allowed'
                                : 'bg-[#e5eeff] text-[#0b1c30] border border-[#c4c5d5] hover:border-[#00288e] hover:bg-[#dce9ff]'
                            }`}
                          >
                            {seatId}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar / Checkout & E-Ticket Preview (4 Columns) */}
        <div className="lg:col-span-4 flex flex-col gap-6">
          {/* Fare Summary Card */}
          <div className="bg-[#ffffff] border border-[#c4c5d5] rounded-xl p-6 shadow-[0_4px_10px_rgba(0,0,0,0.04)] sticky top-24">
            <h2 className="text-xl font-bold text-[#0b1c30] mb-6">
              Booking Summary
            </h2>
            <div className="flex flex-col gap-3.5 border-b border-[#c4c5d5] pb-4 mb-4">
              <div className="flex justify-between items-center text-sm">
                <span className="text-[#444653]">Ticket (1x Adult)</span>
                <span className="text-[#0b1c30] font-medium">${ticketBasePrice.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-[#444653]">Seat Selection ({selectedSeat})</span>
                <span className="text-[#0b1c30] font-medium">${seatFee.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-[#444653]">Taxes &amp; Fees</span>
                <span className="text-[#0b1c30] font-medium">${taxesAndFees.toFixed(2)}</span>
              </div>
            </div>

            <div className="flex justify-between items-center mb-6">
              <span className="text-base font-bold text-[#0b1c30]">Total Fare</span>
              <span className="text-2xl font-bold text-[#00288e]">${totalFare.toFixed(2)}</span>
            </div>

            <button
              id="btn-continue-payment"
              onClick={() => setShowCheckoutModal(true)}
              className="w-full bg-[#00288e] text-white text-sm font-semibold py-3 rounded-lg hover:bg-[#00288e]/90 transition-all shadow-sm flex items-center justify-center gap-2 active:scale-98"
            >
              Continue to Payment
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* E-Ticket Preview Card */}
          <div className="bg-[#ffffff] border border-[#c4c5d5] rounded-xl shadow-sm overflow-hidden">
            <div className="bg-[#1e40af] p-4 text-white flex justify-between items-center">
              <span className="text-sm font-semibold">E-Ticket Preview</span>
              <Ticket className="w-4 h-4 text-[#a8b8ff]" />
            </div>

            <div className="p-6 flex flex-col items-center border-b border-[#c4c5d5] border-dashed">
              <div className="w-32 h-32 bg-[#f8f9ff] flex items-center justify-center p-2 rounded-lg border border-[#c4c5d5]/50 mb-4 shadow-inner">
                <img
                  src={QR_CODE_IMAGE}
                  alt="Booking QR Code"
                  className="object-contain w-full h-full"
                  referrerPolicy="no-referrer"
                />
              </div>
              <p className="text-xs text-[#444653] text-center">
                Scan at boarding or show confirmation PNR: <br />
                <span className="font-bold text-[#0b1c30] text-sm tracking-widest mt-1 inline-block">
                  SBC-892X4
                </span>
              </p>
              <div className="mt-2 inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#eff4ff] text-[#00288e] text-xs font-semibold">
                <span>Seat: {selectedSeat}</span>
              </div>
            </div>

            <div className="p-4 bg-[#f8f9ff] text-center">
              <p className="text-xs font-semibold text-[#0b1c30]">
                {currentRoute.operator}
              </p>
              <p className="text-xs text-[#444653] mt-0.5">
                {searchQuery.date || 'Oct 24, 2024'} • {currentRoute.departureTime}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Payment & Checkout Modal */}
      {showCheckoutModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-[#c4c5d5] relative animate-in fade-in zoom-in duration-200">
            <button
              onClick={() => setShowCheckoutModal(false)}
              className="absolute top-5 right-5 text-[#757684] hover:text-[#0b1c30] p-1 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-xl bg-[#eff4ff] flex items-center justify-center text-[#00288e]">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-[#0b1c30]">Complete Passenger Booking</h3>
                <p className="text-xs text-[#444653]">Instant confirmation &amp; digital e-ticket</p>
              </div>
            </div>

            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-xs font-semibold text-[#0b1c30] mb-1">
                  Passenger Full Name
                </label>
                <input
                  type="text"
                  value={passengerName}
                  onChange={(e) => setPassengerName(e.target.value)}
                  className="w-full h-11 px-3.5 rounded-lg border border-[#c4c5d5] focus:border-[#00288e] text-sm text-[#0b1c30] outline-none"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-[#0b1c30] mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    value={passengerEmail}
                    onChange={(e) => setPassengerEmail(e.target.value)}
                    className="w-full h-11 px-3.5 rounded-lg border border-[#c4c5d5] focus:border-[#00288e] text-sm text-[#0b1c30] outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-[#0b1c30] mb-1">
                    Mobile Phone
                  </label>
                  <input
                    type="tel"
                    value={passengerPhone}
                    onChange={(e) => setPassengerPhone(e.target.value)}
                    className="w-full h-11 px-3.5 rounded-lg border border-[#c4c5d5] focus:border-[#00288e] text-sm text-[#0b1c30] outline-none"
                    required
                  />
                </div>
              </div>

              {/* Trip summary badge */}
              <div className="bg-[#eff4ff] p-4 rounded-xl border border-[#c4c5d5]/50 flex justify-between items-center text-xs">
                <div>
                  <p className="font-bold text-[#00288e]">{currentRoute.operator}</p>
                  <p className="text-[#444653] mt-0.5">
                    Seat {selectedSeat} • {currentRoute.departureTime} - {currentRoute.arrivalTime}
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-xs text-[#757684]">Amount Due</span>
                  <p className="text-lg font-bold text-[#00288e]">${totalFare.toFixed(2)}</p>
                </div>
              </div>
            </div>

            <button
              onClick={handleConfirmPayment}
              disabled={isProcessing}
              className="w-full bg-[#00288e] hover:bg-[#00288e]/90 text-white font-semibold py-3.5 rounded-xl transition-all shadow-md flex items-center justify-center gap-2"
            >
              {isProcessing ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span>Confirming Reservation...</span>
                </>
              ) : (
                <>
                  <Check className="w-5 h-5 text-[#6ffbbe]" />
                  <span>Pay ${totalFare.toFixed(2)} &amp; Issue Ticket</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
