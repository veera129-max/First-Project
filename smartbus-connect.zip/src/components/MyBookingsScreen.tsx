import React, { useState } from 'react';
import { Booking, ScreenType } from '../types';
import { Ticket, Calendar, MapPin, Download, Printer, CheckCircle, ArrowRight } from 'lucide-react';

interface MyBookingsScreenProps {
  bookings: Booking[];
  onNavigate: (screen: ScreenType) => void;
}

export const MyBookingsScreen: React.FC<MyBookingsScreenProps> = ({
  bookings,
  onNavigate,
}) => {
  const [selectedBookingPnr, setSelectedBookingPnr] = useState<string>(
    bookings[0]?.pnr || ''
  );

  const selectedBooking =
    bookings.find((b) => b.pnr === selectedBookingPnr) || bookings[0];

  return (
    <div className="pt-20 pb-20 max-w-7xl mx-auto px-4 sm:px-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-[#0b1c30]">
            My Bookings &amp; Boarding Passes
          </h1>
          <p className="text-sm text-[#444653] mt-1">
            Access your confirmed e-tickets, boarding barcodes, and trip updates.
          </p>
        </div>
        <button
          onClick={() => onNavigate('departure')}
          className="bg-[#00288e] text-white text-sm font-semibold px-4 py-2 rounded-lg hover:bg-[#00288e]/90 transition-all flex items-center gap-2"
        >
          Book New Route
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {bookings.length === 0 ? (
        <div className="bg-white rounded-2xl p-12 text-center border border-[#c4c5d5] max-w-lg mx-auto shadow-sm">
          <div className="w-16 h-16 rounded-full bg-[#eff4ff] flex items-center justify-center mx-auto mb-4 text-[#00288e]">
            <Ticket className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-bold text-[#0b1c30] mb-2">No Active Bookings</h3>
          <p className="text-sm text-[#444653] mb-6">
            You don't have any bus tickets booked yet. Search and reserve your next trip in seconds!
          </p>
          <button
            onClick={() => onNavigate('departure')}
            className="bg-[#00288e] text-white text-sm font-semibold px-6 py-2.5 rounded-lg"
          >
            Find &amp; Book Routes
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Booking Cards List (5 Columns) */}
          <div className="lg:col-span-5 space-y-4">
            {bookings.map((booking) => {
              const isSelected = booking.pnr === selectedBookingPnr;
              return (
                <div
                  key={booking.pnr}
                  onClick={() => setSelectedBookingPnr(booking.pnr)}
                  className={`p-5 rounded-xl cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-[#eff4ff] border-2 border-[#00288e] shadow-md'
                      : 'bg-white border border-[#c4c5d5] hover:shadow-md'
                  }`}
                >
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <span className="text-xs font-mono font-bold text-[#00288e] bg-white px-2 py-0.5 rounded border border-[#c4c5d5]">
                        PNR: {booking.pnr}
                      </span>
                      <h4 className="text-base font-bold text-[#0b1c30] mt-1">
                        {booking.routeName}
                      </h4>
                    </div>
                    <span className="px-2.5 py-1 rounded-full bg-[#006c49]/10 text-[#006c49] text-xs font-semibold flex items-center gap-1">
                      <CheckCircle className="w-3.5 h-3.5" />
                      {booking.status}
                    </span>
                  </div>

                  <div className="text-xs text-[#444653] space-y-1">
                    <p className="flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-[#00288e]" />
                      {booking.date} • {booking.departureTime}
                    </p>
                    <p className="flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-[#006c49]" />
                      Seat: <strong className="text-[#0b1c30]">{booking.seat}</strong> ({booking.passengerName})
                    </p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Full Boarding Pass View (7 Columns) */}
          {selectedBooking && (
            <div className="lg:col-span-7">
              <div className="bg-white border border-[#c4c5d5] rounded-2xl shadow-lg overflow-hidden">
                {/* Header */}
                <div className="bg-[#00288e] text-white p-6 flex justify-between items-center">
                  <div>
                    <span className="text-xs uppercase tracking-widest text-[#a8b8ff]">
                      Official Boarding Pass
                    </span>
                    <h3 className="text-2xl font-bold mt-1">
                      SmartBus Connect
                    </h3>
                  </div>
                  <div className="text-right">
                    <span className="text-xs text-[#a8b8ff] block">PNR Reference</span>
                    <span className="text-xl font-mono font-bold tracking-widest text-[#6ffbbe]">
                      {selectedBooking.pnr}
                    </span>
                  </div>
                </div>

                {/* Details */}
                <div className="p-6 sm:p-8 space-y-6">
                  {/* Passenger & Route */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 border-b border-[#c4c5d5]/50 pb-6">
                    <div>
                      <span className="text-xs text-[#757684]">Passenger</span>
                      <p className="text-sm font-bold text-[#0b1c30]">
                        {selectedBooking.passengerName}
                      </p>
                    </div>
                    <div>
                      <span className="text-xs text-[#757684]">Assigned Seat</span>
                      <p className="text-base font-bold text-[#00288e]">
                        {selectedBooking.seat}
                      </p>
                    </div>
                    <div>
                      <span className="text-xs text-[#757684]">Travel Date</span>
                      <p className="text-sm font-bold text-[#0b1c30]">
                        {selectedBooking.date}
                      </p>
                    </div>
                    <div>
                      <span className="text-xs text-[#757684]">Total Paid</span>
                      <p className="text-base font-bold text-[#006c49]">
                        ${selectedBooking.totalFare.toFixed(2)}
                      </p>
                    </div>
                  </div>

                  {/* Route Timeline */}
                  <div className="flex items-center justify-between bg-[#eff4ff] p-5 rounded-xl border border-[#c4c5d5]/50">
                    <div>
                      <span className="text-xs font-semibold text-[#757684]">Departure</span>
                      <p className="text-xl font-bold text-[#0b1c30]">
                        {selectedBooking.departureTime}
                      </p>
                      <p className="text-xs text-[#444653] mt-0.5">
                        {selectedBooking.origin}
                      </p>
                    </div>

                    <div className="flex flex-col items-center px-4">
                      <span className="text-xs font-semibold text-[#00288e]">Express Transit</span>
                      <div className="w-24 h-0.5 bg-[#00288e] relative my-1">
                        <div className="w-2 h-2 rounded-full bg-[#00288e] absolute -left-1 -top-[3px]"></div>
                        <div className="w-2 h-2 rounded-full bg-[#00288e] absolute -right-1 -top-[3px]"></div>
                      </div>
                      <span className="text-[11px] text-[#006c49] font-medium">Direct Non-Stop</span>
                    </div>

                    <div className="text-right">
                      <span className="text-xs font-semibold text-[#757684]">Arrival</span>
                      <p className="text-xl font-bold text-[#0b1c30]">
                        {selectedBooking.arrivalTime}
                      </p>
                      <p className="text-xs text-[#444653] mt-0.5">
                        {selectedBooking.destination}
                      </p>
                    </div>
                  </div>

                  {/* QR Code Barcode section */}
                  <div className="flex flex-col sm:flex-row items-center justify-between gap-6 border-t border-[#c4c5d5]/50 pt-6">
                    <div className="flex items-center gap-4">
                      <div className="w-24 h-24 bg-white p-1 rounded-lg border border-[#c4c5d5] shadow-sm">
                        <img
                          src={selectedBooking.qrCodeUrl}
                          alt="Boarding QR Code"
                          className="w-full h-full object-contain"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                      <div>
                        <p className="text-xs text-[#444653]">
                          Present this code at Gate 14 boarding scanner.
                        </p>
                        <p className="text-xs font-mono font-bold text-[#0b1c30] mt-1">
                          BARCODE: *{selectedBooking.pnr}*
                        </p>
                      </div>
                    </div>

                    <div className="flex gap-2 w-full sm:w-auto">
                      <button
                        onClick={() => window.print()}
                        className="flex-1 sm:flex-none px-4 py-2.5 border border-[#c4c5d5] rounded-lg text-xs font-semibold hover:bg-[#eff4ff] flex items-center justify-center gap-1.5 transition-colors"
                      >
                        <Printer className="w-4 h-4" />
                        Print
                      </button>
                      <button
                        onClick={() => alert(`Downloaded digital ticket pass for ${selectedBooking.passengerName} (PNR: ${selectedBooking.pnr})`)}
                        className="flex-1 sm:flex-none px-4 py-2.5 bg-[#00288e] text-white rounded-lg text-xs font-semibold hover:bg-[#00288e]/90 flex items-center justify-center gap-1.5 transition-colors"
                      >
                        <Download className="w-4 h-4" />
                        Save PDF
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
