import React, { useState } from 'react';
import { CITY_HUB_IMAGE } from '../data/mockData';
import { MapPin, Calendar, Search, ArrowRight, Shield, Zap, Clock } from 'lucide-react';

interface HomeScreenProps {
  onSearch: (source: string, destination: string, date: string) => void;
  onOpenPortal: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({ onSearch, onOpenPortal }) => {
  const [source, setSource] = useState('New York (NYC)');
  const [destination, setDestination] = useState('Boston (BOS)');
  const [date, setDate] = useState('2024-10-24');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(source, destination, date);
  };

  const handleQuickRoute = (src: string, dst: string) => {
    setSource(src);
    setDestination(dst);
    onSearch(src, dst, date);
  };

  return (
    <div className="min-h-screen flex flex-col justify-between">
      <main className="pt-24 pb-16">
        {/* Hero Section */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 mb-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-3xl sm:text-4xl lg:text-[48px] leading-tight font-bold tracking-tight text-[#0b1c30] mb-6">
                Smart Bus Travel &amp; Fleet Management
              </h1>
              <p className="text-lg text-[#444653] leading-relaxed mb-8">
                Efficient, reliable, and real-time logistics for the modern transit ecosystem.
              </p>

              {/* Search Form Card */}
              <div className="bg-[#ffffff] p-6 rounded-xl border border-[#c4c5d5] shadow-[0_4px_10px_rgba(0,0,0,0.04)]">
                <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {/* Source */}
                  <div className="relative">
                    <MapPin className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-[#444653]" />
                    <input
                      id="input-source"
                      type="text"
                      value={source}
                      onChange={(e) => setSource(e.target.value)}
                      placeholder="Source"
                      required
                      className="w-full h-[44px] pl-10 pr-3 rounded-lg border border-[#c4c5d5] focus:border-[#00288e] focus:ring-1 focus:ring-[#00288e] text-sm text-[#0b1c30] bg-[#f8f9ff] outline-none transition-colors"
                    />
                  </div>

                  {/* Destination */}
                  <div className="relative">
                    <MapPin className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-[#444653]" />
                    <input
                      id="input-destination"
                      type="text"
                      value={destination}
                      onChange={(e) => setDestination(e.target.value)}
                      placeholder="Destination"
                      required
                      className="w-full h-[44px] pl-10 pr-3 rounded-lg border border-[#c4c5d5] focus:border-[#00288e] focus:ring-1 focus:ring-[#00288e] text-sm text-[#0b1c30] bg-[#f8f9ff] outline-none transition-colors"
                    />
                  </div>

                  {/* Date */}
                  <div className="relative">
                    <Calendar className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-[#444653]" />
                    <input
                      id="input-date"
                      type="date"
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      required
                      className="w-full h-[44px] pl-10 pr-3 rounded-lg border border-[#c4c5d5] focus:border-[#00288e] focus:ring-1 focus:ring-[#00288e] text-sm text-[#0b1c30] bg-[#f8f9ff] outline-none transition-colors"
                    />
                  </div>

                  {/* Submit Button */}
                  <div className="md:col-span-3 flex flex-col sm:flex-row items-center justify-between gap-4 mt-2">
                    <div className="flex items-center gap-2 text-xs text-[#757684]">
                      <span>Popular:</span>
                      <button
                        type="button"
                        onClick={() => handleQuickRoute('New York (NYC)', 'Boston (BOS)')}
                        className="text-[#00288e] hover:underline font-medium"
                      >
                        NYC → BOS
                      </button>
                      <span>•</span>
                      <button
                        type="button"
                        onClick={() => handleQuickRoute('New York (NYC)', 'Washington (DC)')}
                        className="text-[#00288e] hover:underline font-medium"
                      >
                        NYC → DC
                      </button>
                      <span>•</span>
                      <button
                        type="button"
                        onClick={() => handleQuickRoute('Chicago (CHI)', 'Detroit (DET)')}
                        className="text-[#00288e] hover:underline font-medium"
                      >
                        CHI → DET
                      </button>
                    </div>

                    <button
                      id="btn-search-buses"
                      type="submit"
                      className="bg-[#00288e] text-white text-sm font-semibold px-6 py-2.5 rounded-lg hover:bg-[#00288e]/90 transition-all flex items-center gap-2 shadow-sm w-full sm:w-auto justify-center active:scale-95"
                    >
                      <Search className="w-4 h-4" />
                      Search Buses
                    </button>
                  </div>
                </form>
              </div>

              {/* Quick perks preview */}
              <div className="grid grid-cols-3 gap-4 mt-8 pt-6 border-t border-[#c4c5d5]/40">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-[#eff4ff] flex items-center justify-center text-[#00288e]">
                    <Clock className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs text-[#757684]">Punctuality</p>
                    <p className="text-sm font-semibold text-[#0b1c30]">99.4% On-Time</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-[#eff4ff] flex items-center justify-center text-[#006c49]">
                    <Zap className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs text-[#757684]">Fleet Tech</p>
                    <p className="text-sm font-semibold text-[#0b1c30]">Live GPS & WiFi</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-[#eff4ff] flex items-center justify-center text-[#1e40af]">
                    <Shield className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs text-[#757684]">Safety</p>
                    <p className="text-sm font-semibold text-[#0b1c30]">Verified Fleet</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Hero Visual Banner */}
            <div className="relative h-[340px] sm:h-[420px] rounded-2xl overflow-hidden shadow-xl border border-[#c4c5d5] group">
              <img
                src={CITY_HUB_IMAGE}
                alt="SmartBus Connect Transit Hub"
                className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0b1c30]/70 via-transparent to-transparent"></div>
              
              <div className="absolute bottom-6 left-6 right-6 flex items-center justify-between text-white">
                <div>
                  <span className="text-xs font-semibold uppercase tracking-wider text-[#6ffbbe] bg-[#006c49]/80 px-2.5 py-1 rounded-full backdrop-blur-md">
                    Smart Transit Hub
                  </span>
                  <h3 className="text-lg font-bold mt-2 text-white">Connected Transit Logistics</h3>
                </div>
                <button
                  onClick={onOpenPortal}
                  className="bg-white/95 text-[#00288e] text-xs font-bold px-3.5 py-2 rounded-lg hover:bg-white transition-all flex items-center gap-1.5 shadow-md"
                >
                  Live Dispatch
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer (Shared Component) */}
      <footer className="bg-[#ffffff] w-full py-12 border-t border-[#c4c5d5] mt-12">
        <div className="max-w-7xl mx-auto px-6 sm:px-8 grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <span className="text-xl font-bold text-[#00288e] block mb-3">
              SmartBus Connect
            </span>
            <p className="text-sm text-[#444653]">
              © 2024 SmartBus Connect. Logistics Excellence.
            </p>
          </div>
          <div className="flex flex-col gap-2.5">
            <h4 className="text-sm font-semibold text-[#0b1c30] mb-1">Legal</h4>
            <a href="#" onClick={(e) => { e.preventDefault(); alert('SmartBus Privacy Policy: All passenger data and telemetry is securely encrypted.'); }} className="text-sm text-[#444653] hover:text-[#00288e] transition-colors">
              Privacy Policy
            </a>
            <a href="#" onClick={(e) => { e.preventDefault(); alert('SmartBus Terms of Service: Safe travel and booking guarantees.'); }} className="text-sm text-[#444653] hover:text-[#00288e] transition-colors">
              Terms of Service
            </a>
          </div>
          <div className="flex flex-col gap-2.5">
            <h4 className="text-sm font-semibold text-[#0b1c30] mb-1">Company</h4>
            <a href="#" onClick={(e) => { e.preventDefault(); onOpenPortal(); }} className="text-sm text-[#444653] hover:text-[#00288e] transition-colors">
              Fleet Solutions
            </a>
            <a href="#" onClick={(e) => { e.preventDefault(); alert('We are hiring transit logistics engineers and dispatchers! Contact careers@smartbus.com'); }} className="text-sm text-[#444653] hover:text-[#00288e] transition-colors">
              Careers
            </a>
          </div>
          <div className="flex flex-col gap-2.5">
            <h4 className="text-sm font-semibold text-[#0b1c30] mb-1">Support</h4>
            <a href="#" onClick={(e) => { e.preventDefault(); alert('Customer Service Hotline: +1 (800) 555-BUS1 (24/7 Support)'); }} className="text-sm text-[#444653] hover:text-[#00288e] transition-colors">
              Contact Support
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
};
