import React, { useState } from 'react';
import { COMMAND_CENTER_IMAGE } from '../data/mockData';
import { ScreenType } from '../types';
import {
  Bus,
  User,
  Lock,
  Eye,
  EyeOff,
  Key,
  Smartphone,
  ArrowLeft,
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';

interface SignInScreenProps {
  onLoginSuccess: (role: 'admin' | 'passenger') => void;
  onNavigate: (screen: ScreenType) => void;
}

export const SignInScreen: React.FC<SignInScreenProps> = ({
  onLoginSuccess,
  onNavigate,
}) => {
  const [email, setEmail] = useState('admin@smartbus.com');
  const [password, setPassword] = useState('••••••••');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      const role = email.toLowerCase().includes('admin') ? 'admin' : 'passenger';
      onLoginSuccess(role);
    }, 800);
  };

  const handleQuickLogin = (role: 'admin' | 'passenger') => {
    if (role === 'admin') {
      setEmail('admin@smartbus.com');
      setPassword('AdminPass123!');
      onLoginSuccess('admin');
    } else {
      setEmail('alex.morgan@example.com');
      setPassword('Passenger123!');
      onLoginSuccess('passenger');
    }
  };

  return (
    <main className="flex w-full min-h-screen bg-[#f8f9ff]">
      {/* Left Side: Brand Imagery & Welcome (Hidden on Mobile) */}
      <section className="hidden lg:flex lg:w-1/2 relative bg-[#1e40af] items-center justify-center overflow-hidden">
        {/* Background Image */}
        <div
          className="absolute inset-0 z-0 bg-cover bg-center"
          style={{ backgroundImage: `url('${COMMAND_CENTER_IMAGE}')` }}
        >
          {/* Overlay for readability & high-tech corporate blue vibe */}
          <div className="absolute inset-0 bg-[#b8c4ff]/30 backdrop-blur-sm mix-blend-multiply"></div>
          <div className="absolute inset-0 bg-gradient-to-t from-[#00288e]/95 via-[#00288e]/60 to-transparent"></div>
        </div>

        {/* Brand Content Overlay */}
        <div className="relative z-10 p-12 max-w-lg text-white">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-12 h-12 rounded-xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20">
              <Bus className="w-8 h-8 text-[#f8f9ff]" />
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-white">
              SmartBus Connect
            </h1>
          </div>

          <h2 className="text-4xl sm:text-5xl font-bold leading-tight mb-4 text-white">
            Logistics Excellence.
          </h2>

          <p className="text-base sm:text-lg text-[#dde1ff]/90 leading-relaxed mb-8">
            Access the central control hub to monitor fleets, manage schedules, and optimize routes with precision and reliability.
          </p>

          {/* System Status Indicator */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-[#6cf8bb]/20 rounded-full border border-[#6cf8bb]/30 backdrop-blur-md">
            <div className="w-2.5 h-2.5 rounded-full bg-[#6ffbbe] animate-pulse"></div>
            <span className="text-xs font-semibold text-[#6ffbbe] tracking-wide">
              System Operational
            </span>
          </div>
        </div>
      </section>

      {/* Right Side: Login Form */}
      <section className="w-full lg:w-1/2 flex flex-col justify-between p-6 sm:p-12 bg-[#ffffff]">
        {/* Back to main portal link */}
        <div className="flex justify-between items-center mb-6">
          <button
            onClick={() => onNavigate('home')}
            className="text-xs font-semibold text-[#444653] hover:text-[#00288e] flex items-center gap-1.5 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Public Portal
          </button>
        </div>

        <div className="w-full max-w-md mx-auto my-auto">
          {/* Mobile Logo */}
          <div className="lg:hidden flex items-center justify-center gap-2 mb-6">
            <div className="w-8 h-8 rounded-lg bg-[#00288e] flex items-center justify-center text-white">
              <Bus className="w-5 h-5" />
            </div>
            <h1 className="text-xl font-bold text-[#00288e]">SmartBus Connect</h1>
          </div>

          {/* Form Header */}
          <div className="mb-6">
            <h2 className="text-2xl sm:text-3xl font-bold text-[#0b1c30] mb-1">
              Sign In
            </h2>
            <p className="text-sm text-[#444653]">
              Enter your credentials to access the admin portal.
            </p>
          </div>

          {/* Quick Demo Credentials Bar for Easy Review */}
          <div className="bg-[#eff4ff] border border-[#c4c5d5]/60 rounded-xl p-3.5 mb-5 text-xs flex flex-col gap-2">
            <span className="font-semibold text-[#00288e] flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-[#006c49]" />
              Quick One-Click Demo Access:
            </span>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => handleQuickLogin('admin')}
                className="flex-1 py-1.5 px-2.5 bg-[#00288e] text-white font-medium rounded-lg text-center hover:bg-[#00288e]/90 transition-colors"
              >
                Sign In as Admin
              </button>
              <button
                type="button"
                onClick={() => handleQuickLogin('passenger')}
                className="flex-1 py-1.5 px-2.5 bg-white border border-[#c4c5d5] text-[#0b1c30] font-medium rounded-lg text-center hover:bg-[#dce9ff] transition-colors"
              >
                Sign In as Passenger
              </button>
            </div>
          </div>

          {/* Login Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Email/Username */}
            <div className="space-y-1">
              <label className="block text-xs font-semibold text-[#0b1c30]" htmlFor="email">
                Email or Username
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#757684]">
                  <User className="w-4 h-4" />
                </div>
                <input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="admin@smartbus.com"
                  required
                  className="block w-full h-[44px] pl-10 pr-3 bg-[#f8f9ff] border border-[#c4c5d5] rounded-lg text-sm text-[#0b1c30] placeholder:text-[#757684] focus:ring-1 focus:ring-[#00288e] focus:border-[#00288e] transition-colors outline-none"
                />
              </div>
            </div>

            {/* Password */}
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <label className="block text-xs font-semibold text-[#0b1c30]" htmlFor="password">
                  Password
                </label>
                <a
                  href="#"
                  onClick={(e) => {
                    e.preventDefault();
                    alert('Password reset link sent to registered email.');
                  }}
                  className="text-xs text-[#00288e] hover:underline"
                >
                  Forgot Password?
                </a>
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#757684]">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  className="block w-full h-[44px] pl-10 pr-10 bg-[#f8f9ff] border border-[#c4c5d5] rounded-lg text-sm text-[#0b1c30] placeholder:text-[#757684] focus:ring-1 focus:ring-[#00288e] focus:border-[#00288e] transition-colors outline-none"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  aria-label="Toggle password visibility"
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-[#757684] hover:text-[#0b1c30]"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Remember Me */}
            <div className="flex items-center pt-1 pb-1">
              <input
                id="remember-me"
                type="checkbox"
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
                className="h-4 w-4 rounded border-[#c4c5d5] text-[#00288e] focus:ring-[#00288e] bg-[#f8f9ff] cursor-pointer"
              />
              <label htmlFor="remember-me" className="ml-2 block text-xs text-[#444653] cursor-pointer">
                Remember this device
              </label>
            </div>

            {/* Submit Button */}
            <button
              id="btn-submit-signin"
              type="submit"
              disabled={isLoading}
              className="w-full flex justify-center items-center py-2.5 px-4 rounded-lg shadow-sm text-sm font-semibold text-white bg-[#00288e] hover:bg-[#1e40af] transition-all active:scale-[0.98]"
            >
              {isLoading ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : (
                'Sign In'
              )}
            </button>
          </form>

          {/* Divider */}
          <div className="mt-6 relative">
            <div aria-hidden="true" className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-[#c4c5d5]"></div>
            </div>
            <div className="relative flex justify-center text-xs">
              <span className="px-3 bg-white text-[#757684]">Or continue with</span>
            </div>
          </div>

          {/* Social Logins */}
          <div className="mt-6 grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => handleQuickLogin('admin')}
              className="flex w-full items-center justify-center gap-2 h-[42px] bg-[#ffffff] border border-[#c4c5d5] rounded-lg hover:bg-[#eff4ff] transition-colors text-xs font-semibold text-[#0b1c30]"
            >
              <Key className="w-4 h-4 text-[#00288e]" />
              SSO
            </button>
            <button
              type="button"
              onClick={() => handleQuickLogin('passenger')}
              className="flex w-full items-center justify-center gap-2 h-[42px] bg-[#ffffff] border border-[#c4c5d5] rounded-lg hover:bg-[#eff4ff] transition-colors text-xs font-semibold text-[#0b1c30]"
            >
              <Smartphone className="w-4 h-4 text-[#006c49]" />
              Apple
            </button>
          </div>

          {/* Registration / Support Link */}
          <p className="mt-8 text-center text-xs text-[#444653]">
            Need an administrator account?{' '}
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                alert('Support request submitted for Admin enterprise access.');
              }}
              className="font-semibold text-[#00288e] hover:underline"
            >
              Contact Support
            </a>
          </p>
        </div>

        <div className="text-center text-[11px] text-[#757684] pt-4">
          SmartBus Connect • Enterprise Logistics Portal
        </div>
      </section>
    </main>
  );
};
