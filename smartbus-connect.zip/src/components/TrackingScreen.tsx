import React, { useState, useEffect } from 'react';
import { FleetVehicle, ScreenType } from '../types';
import { INITIAL_FLEET, MAP_BG_IMAGE } from '../data/mockData';
import {
  Bus,
  DollarSign,
  Users,
  Map as MapIcon,
  Wrench,
  Settings,
  Plus,
  HelpCircle,
  LogOut,
  Search,
  MoreVertical,
  User,
  Navigation,
  Layers,
  ZoomIn,
  ZoomOut,
  Radio,
  Clock,
  Gauge,
  CheckCircle2,
  AlertTriangle,
  Send,
  X
} from 'lucide-react';

interface TrackingScreenProps {
  onNavigate: (screen: ScreenType) => void;
  onLogout: () => void;
}

export const TrackingScreen: React.FC<TrackingScreenProps> = ({
  onNavigate,
  onLogout,
}) => {
  const [fleet, setFleet] = useState<FleetVehicle[]>(INITIAL_FLEET);
  const [selectedBusId, setSelectedBusId] = useState<string>('4092');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'in-transit' | 'delayed'>('in-transit');
  const [mapZoom, setMapZoom] = useState<number>(1);
  const [mapLayer, setMapLayer] = useState<'standard' | 'traffic' | 'satellite'>('traffic');
  const [showAddVehicleModal, setShowAddVehicleModal] = useState<boolean>(false);
  const [showRouteStatusModal, setShowRouteStatusModal] = useState<boolean>(false);
  const [liveSimActive, setLiveSimActive] = useState<boolean>(true);

  // New vehicle state
  const [newBusNumber, setNewBusNumber] = useState('');
  const [newBusRoute, setNewBusRoute] = useState('');
  const [newDriverName, setNewDriverName] = useState('');

  // Live speed oscillation simulation
  useEffect(() => {
    if (!liveSimActive) return;
    const interval = setInterval(() => {
      setFleet((prev) =>
        prev.map((bus) => {
          if (!bus.inTransit) return bus;
          const speedVariance = (Math.random() - 0.5) * 4;
          const nextSpeed = Math.max(30, Math.min(72, Math.round(bus.speed + speedVariance)));
          return {
            ...bus,
            speed: nextSpeed,
          };
        })
      );
    }, 3000);
    return () => clearInterval(interval);
  }, [liveSimActive]);

  const selectedBus = fleet.find((b) => b.id === selectedBusId) || fleet[0];

  const filteredFleet = fleet.filter((bus) => {
    const matchesQuery =
      bus.number.toLowerCase().includes(searchQuery.toLowerCase()) ||
      bus.route.toLowerCase().includes(searchQuery.toLowerCase()) ||
      bus.driverName.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesQuery) return false;
    if (statusFilter === 'in-transit') return bus.inTransit;
    if (statusFilter === 'delayed') return bus.status === 'Delayed';
    return true;
  });

  const handleAddVehicle = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBusNumber || !newBusRoute) return;
    const newId = Math.floor(1000 + Math.random() * 9000).toString();
    const newVehicle: FleetVehicle = {
      id: newId,
      number: `Bus #${newBusNumber.replace('#', '')}`,
      route: newBusRoute,
      origin: 'New York City',
      destination: 'Boston',
      type: 'Express',
      driverName: newDriverName || 'Jordan P.',
      driverId: `D-${Math.floor(1000 + Math.random() * 9000)}`,
      status: 'On Time',
      speed: 52,
      estArrival: '15:20 EST',
      latPct: 38 + Math.random() * 15,
      lngPct: 48 + Math.random() * 15,
      inTransit: true,
      passengerLoad: '38 / 48 (79%)',
      fuelBattery: '95% Electric',
    };
    setFleet([newVehicle, ...fleet]);
    setSelectedBusId(newId);
    setShowAddVehicleModal(false);
    setNewBusNumber('');
    setNewBusRoute('');
    setNewDriverName('');
  };

  return (
    <div className="h-screen w-full overflow-hidden flex bg-[#f8f9ff] text-[#0b1c30]">
      {/* 1. SideNavBar (Shared Admin Component) */}
      <nav className="bg-[#001453] shadow-md border-r border-[#c4c5d5]/30 w-64 lg:w-72 flex flex-col h-full py-6 z-40 shrink-0 select-none">
        {/* Brand Logo & Header */}
        <div 
          onClick={() => onNavigate('home')}
          className="px-6 mb-8 flex items-center gap-3.5 cursor-pointer"
        >
          <div className="w-10 h-10 rounded-full bg-[#00288e] flex items-center justify-center text-white shadow-sm">
            <Bus className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-[#f8f9ff] tracking-tight">
              SmartBus Admin
            </h1>
            <p className="text-xs text-[#d3e4fe]">System Controller</p>
          </div>
        </div>

        {/* Navigation Links */}
        <div className="flex-1 overflow-y-auto px-2">
          <ul className="space-y-1">
            <li>
              <button
                className="w-full bg-[#6cf8bb]/15 text-[#6ffbbe] border-l-4 border-[#6ffbbe] flex items-center gap-3.5 px-4 py-3 text-sm font-semibold rounded-r-lg transition-all"
              >
                <Bus className="w-4 h-4" />
                <span>Fleet Monitor</span>
              </button>
            </li>
            <li>
              <button
                onClick={() => alert('Revenue Analytics: $148,250 MTD revenue, 94.2% seat utilization across 12 corridors.')}
                className="w-full text-[#d3e4fe] flex items-center gap-3.5 px-4 py-3 hover:bg-[#1e40af]/50 text-sm font-medium rounded-lg transition-all"
              >
                <DollarSign className="w-4 h-4" />
                <span>Revenue</span>
              </button>
            </li>
            <li>
              <button
                onClick={() => alert('Driver Roster: 64 certified drivers active, average 4.92 safety score.')}
                className="w-full text-[#d3e4fe] flex items-center gap-3.5 px-4 py-3 hover:bg-[#1e40af]/50 text-sm font-medium rounded-lg transition-all"
              >
                <Users className="w-4 h-4" />
                <span>Drivers</span>
              </button>
            </li>
            <li>
              <button
                onClick={() => onNavigate('departure')}
                className="w-full text-[#d3e4fe] flex items-center gap-3.5 px-4 py-3 hover:bg-[#1e40af]/50 text-sm font-medium rounded-lg transition-all"
              >
                <MapIcon className="w-4 h-4" />
                <span>Routes</span>
              </button>
            </li>
            <li>
              <button
                onClick={() => alert('Fleet Maintenance: 2 vehicles scheduled for standard 20,000 mi diagnostics.')}
                className="w-full text-[#d3e4fe] flex items-center gap-3.5 px-4 py-3 hover:bg-[#1e40af]/50 text-sm font-medium rounded-lg transition-all"
              >
                <Wrench className="w-4 h-4" />
                <span>Maintenance</span>
              </button>
            </li>
            <li>
              <button
                onClick={() => alert('System Settings: Telemetry refresh rate (3s), GPS precision (High), Alerts (Enabled).')}
                className="w-full text-[#d3e4fe] flex items-center gap-3.5 px-4 py-3 hover:bg-[#1e40af]/50 text-sm font-medium rounded-lg transition-all"
              >
                <Settings className="w-4 h-4" />
                <span>Settings</span>
              </button>
            </li>
          </ul>
        </div>

        {/* CTA & Footer */}
        <div className="px-4 mt-auto space-y-3">
          <button
            id="btn-add-vehicle"
            onClick={() => setShowAddVehicleModal(true)}
            className="w-full bg-[#1e40af] text-white py-2.5 rounded-lg text-sm font-semibold hover:bg-[#00288e] transition-colors flex items-center justify-center gap-2 shadow-sm"
          >
            <Plus className="w-4 h-4" />
            Add New Vehicle
          </button>

          <ul className="space-y-1 pt-2 border-t border-[#c4c5d5]/20">
            <li>
              <button
                onClick={() => alert('Admin Help Center: Dispatch Operations manual v4.2 loaded. Hotline available.')}
                className="w-full text-[#d3e4fe] flex items-center gap-3 px-3 py-2 hover:bg-[#1e40af]/40 text-xs font-medium rounded-lg transition-colors"
              >
                <HelpCircle className="w-4 h-4" />
                <span>Help Center</span>
              </button>
            </li>
            <li>
              <button
                onClick={onLogout}
                className="w-full text-[#d3e4fe] hover:text-[#ffdad6] flex items-center gap-3 px-3 py-2 hover:bg-[#ba1a1a]/20 text-xs font-medium rounded-lg transition-colors"
              >
                <LogOut className="w-4 h-4" />
                <span>Logout</span>
              </button>
            </li>
          </ul>
        </div>
      </nav>

      {/* Main Content Area */}
      <main className="flex-1 flex relative overflow-hidden">
        {/* Left Overlay Rail: Bus List & Search */}
        <div className="w-[300px] sm:w-[320px] bg-[#ffffff] shadow-[10px_0_15px_-3px_rgba(0,0,0,0.04)] h-full z-20 flex flex-col border-r border-[#c4c5d5]/40 shrink-0">
          {/* Search & Filters */}
          <div className="p-5 border-b border-[#c4c5d5]/50">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-xl font-bold text-[#0b1c30]">Live Tracking</h2>
              <span className="flex items-center gap-1 text-[11px] text-[#006c49] font-semibold bg-[#eff4ff] px-2 py-0.5 rounded-full">
                <span className="w-1.5 h-1.5 rounded-full bg-[#006c49] animate-ping"></span>
                LIVE
              </span>
            </div>

            <div className="relative mb-3">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#757684]" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search Bus ID, Route, Driver..."
                className="w-full h-9 pl-9 pr-3 rounded-lg border border-[#c4c5d5] focus:border-[#1e40af] focus:ring-1 focus:ring-[#1e40af] outline-none text-xs bg-[#f8f9ff] text-[#0b1c30] transition-colors"
              />
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => setStatusFilter('all')}
                className={`flex-1 py-1 px-2.5 rounded-full text-xs font-semibold border transition-colors ${
                  statusFilter === 'all'
                    ? 'bg-[#1e40af] text-white border-[#1e40af]'
                    : 'bg-[#d3e4fe] text-[#444653] border-[#c4c5d5]/50 hover:bg-[#dce9ff]'
                }`}
              >
                All Status
              </button>
              <button
                onClick={() => setStatusFilter('in-transit')}
                className={`flex-1 py-1 px-2.5 rounded-full text-xs font-semibold border transition-colors ${
                  statusFilter === 'in-transit'
                    ? 'bg-[#1e40af] text-white border-[#1e40af]'
                    : 'bg-[#eff4ff] text-[#1e40af] border-[#1e40af]/30 hover:bg-[#e5eeff]'
                }`}
              >
                In-Transit
              </button>
              <button
                onClick={() => setStatusFilter('delayed')}
                className={`flex-1 py-1 px-2.5 rounded-full text-xs font-semibold border transition-colors ${
                  statusFilter === 'delayed'
                    ? 'bg-[#ba1a1a] text-white border-[#ba1a1a]'
                    : 'bg-[#eff4ff] text-[#ba1a1a] border-[#ba1a1a]/30 hover:bg-[#ffdad6]'
                }`}
              >
                Delayed
              </button>
            </div>
          </div>

          {/* Bus Cards List */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {filteredFleet.map((bus) => {
              const isSelected = bus.id === selectedBusId;
              const isDelayed = bus.status === 'Delayed';

              return (
                <div
                  key={bus.id}
                  id={`bus-item-${bus.id}`}
                  onClick={() => setSelectedBusId(bus.id)}
                  className={`rounded-xl p-3.5 cursor-pointer relative overflow-hidden transition-all ${
                    isSelected
                      ? 'bg-[#ffffff] border border-[#1e40af] shadow-[0_8px_15px_-3px_rgba(0,0,0,0.08)] ring-1 ring-[#1e40af]'
                      : 'bg-[#ffffff] border border-[#c4c5d5]/60 hover:shadow-md'
                  }`}
                >
                  {/* Left accent indicator for selected */}
                  {isSelected && (
                    <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-[#1e40af]"></div>
                  )}

                  <div className="flex justify-between items-start mb-1.5 pl-1.5">
                    <span className="text-sm font-bold text-[#0b1c30]">
                      {bus.number}
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded-full text-[11px] font-semibold flex items-center gap-1 ${
                        isDelayed
                          ? 'bg-[#ffdad6] text-[#ba1a1a]'
                          : 'bg-[#006c49]/10 text-[#006c49]'
                      }`}
                    >
                      <span
                        className={`w-1.5 h-1.5 rounded-full ${
                          isDelayed ? 'bg-[#ba1a1a]' : 'bg-[#006c49]'
                        }`}
                      ></span>
                      {bus.status}
                    </span>
                  </div>

                  <div className="pl-1.5 space-y-0.5">
                    <p className="text-xs font-medium text-[#444653]">
                      {bus.route}
                    </p>
                    <div className="flex items-center justify-between text-[11px] text-[#757684]">
                      <span>Driver: {bus.driverName}</span>
                      <span className="font-semibold text-[#1e40af]">{bus.speed} mph</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Center Interactive Map Area */}
        <div className="flex-1 h-full relative overflow-hidden bg-[#e5eeff]">
          {/* Map Base Canvas with Zoom */}
          <div
            className="absolute inset-0 bg-cover bg-center transition-transform duration-500"
            style={{
              backgroundImage: `url('${MAP_BG_IMAGE}')`,
              transform: `scale(${mapZoom})`,
            }}
          >
            {/* SVG Vector Route Lines */}
            <svg
              className="absolute inset-0 w-full h-full pointer-events-none"
              preserveAspectRatio="none"
              viewBox="0 0 1000 1000"
            >
              {/* Primary NYC-DC Corridor */}
              <path
                d="M 500 400 Q 550 450 600 300"
                fill="none"
                stroke="#1e40af"
                strokeWidth="4"
                strokeDasharray="8 4"
                className="opacity-80 animated-route-dash"
              />
              {/* Secondary Corridor BOS-NYC */}
              <path
                d="M 600 300 Q 640 250 700 200"
                fill="none"
                stroke="#006c49"
                strokeWidth="3"
                strokeDasharray="6 4"
                className="opacity-70"
              />
              {/* Mid-West Corridor CHI-DET */}
              <path
                d="M 450 550 Q 520 520 580 480"
                fill="none"
                stroke="#00288e"
                strokeWidth="3"
                strokeDasharray="6 4"
                className="opacity-70"
              />
            </svg>

            {/* Interactive Vehicle Markers on Map */}
            {fleet.map((bus) => {
              const isSelected = bus.id === selectedBusId;
              const isDelayed = bus.status === 'Delayed';

              return (
                <div
                  key={bus.id}
                  onClick={() => setSelectedBusId(bus.id)}
                  style={{
                    top: `${bus.latPct}%`,
                    left: `${bus.lngPct}%`,
                  }}
                  className="absolute -translate-x-1/2 -translate-y-1/2 cursor-pointer z-10 group"
                >
                  {/* Outer pulse animation for selected bus */}
                  {isSelected ? (
                    <div className="w-5 h-5 bg-[#1e40af] rounded-full pulse-marker flex items-center justify-center text-white shadow-lg border-2 border-white ring-2 ring-[#1e40af]">
                      <span className="w-2 h-2 bg-white rounded-full"></span>
                    </div>
                  ) : (
                    <div
                      className={`w-3.5 h-3.5 rounded-full border-2 border-white shadow-md transition-transform group-hover:scale-125 ${
                        isDelayed ? 'bg-[#ba1a1a]' : 'bg-[#006c49]'
                      }`}
                    ></div>
                  )}

                  {/* Marker Tooltip */}
                  <div className="absolute left-1/2 -translate-x-1/2 -top-8 bg-[#0b1c30] text-white text-[11px] font-semibold px-2 py-0.5 rounded shadow-md whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                    {bus.number} ({bus.speed} mph)
                  </div>
                </div>
              );
            })}
          </div>

          {/* Right Floating Panel: Detailed Bus Telemetry Card */}
          <div className="absolute top-6 right-6 w-[340px] sm:w-[360px] z-30">
            <div className="bg-[#ffffff] rounded-xl border border-[#c4c5d5]/60 shadow-[0_8px_20px_-5px_rgba(0,0,0,0.12)] overflow-hidden animate-in fade-in slide-in-from-right-4 duration-300">
              {/* Header */}
              <div className="bg-[#eff4ff] p-5 border-b border-[#c4c5d5]/40 flex justify-between items-center">
                <div>
                  <h3 className="text-xl font-bold text-[#0b1c30]">
                    {selectedBus.number}
                  </h3>
                  <p className="text-xs text-[#444653] mt-0.5">
                    In-Transit: {selectedBus.origin} to {selectedBus.destination}
                  </p>
                </div>
                <button
                  onClick={() => setShowRouteStatusModal(true)}
                  className="text-[#757684] hover:text-[#0b1c30] p-1.5 rounded-lg hover:bg-white/60 transition-colors"
                  title="Vehicle details"
                >
                  <MoreVertical className="w-5 h-5" />
                </button>
              </div>

              {/* Telemetry Data Grid */}
              <div className="p-5 grid grid-cols-2 gap-3.5">
                <div className="bg-[#f8f9ff] p-3 rounded-lg border border-[#c4c5d5]/40 shadow-inner">
                  <p className="text-[11px] font-medium text-[#757684] mb-1 flex items-center gap-1">
                    <Gauge className="w-3.5 h-3.5 text-[#1e40af]" />
                    Current Speed
                  </p>
                  <p className="text-2xl font-bold text-[#1e40af]">
                    {selectedBus.speed}{' '}
                    <span className="text-xs font-normal text-[#444653]">mph</span>
                  </p>
                </div>

                <div className="bg-[#f8f9ff] p-3 rounded-lg border border-[#c4c5d5]/40 shadow-inner">
                  <p className="text-[11px] font-medium text-[#757684] mb-1 flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-[#006c49]" />
                    Est. Arrival
                  </p>
                  <p className="text-2xl font-bold text-[#0b1c30]">
                    {selectedBus.estArrival.split(' ')[0]}{' '}
                    <span className="text-xs font-normal text-[#444653]">
                      {selectedBus.estArrival.split(' ')[1] || 'EST'}
                    </span>
                  </p>
                </div>

                {/* Additional telemetry metrics */}
                <div className="col-span-2 grid grid-cols-2 gap-2 text-xs py-1 border-t border-b border-[#c4c5d5]/30 my-1">
                  <div>
                    <span className="text-[#757684]">Passenger Load:</span>
                    <p className="font-semibold text-[#0b1c30]">{selectedBus.passengerLoad}</p>
                  </div>
                  <div>
                    <span className="text-[#757684]">Power/Battery:</span>
                    <p className="font-semibold text-[#006c49]">{selectedBus.fuelBattery}</p>
                  </div>
                </div>

                {/* Driver Info Row */}
                <div className="col-span-2 flex items-center justify-between pt-2">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-[#d3e4fe] flex items-center justify-center border border-[#c4c5d5]/50 text-[#1e40af]">
                      <User className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-[#0b1c30]">
                        {selectedBus.driverName}
                      </p>
                      <p className="text-xs text-[#757684]">
                        Driver ID: {selectedBus.driverId}
                      </p>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 rounded-full bg-[#006c49]/10 text-[#006c49] text-xs font-semibold border border-[#006c49]/20">
                    Active
                  </span>
                </div>
              </div>

              {/* Action */}
              <div className="p-5 pt-0">
                <button
                  id="btn-view-route-status"
                  onClick={() => setShowRouteStatusModal(true)}
                  className="w-full bg-[#ffffff] text-[#1e40af] border border-[#c4c5d5] py-2.5 rounded-lg text-sm font-semibold hover:bg-[#eff4ff] transition-all flex items-center justify-center gap-2 shadow-sm"
                >
                  <Navigation className="w-4 h-4" />
                  View Route Status
                </button>
              </div>
            </div>

            {/* Map Controls Floating below detail card */}
            <div className="mt-4 flex flex-col gap-2 items-end">
              <button
                onClick={() => setMapZoom((prev) => Math.min(1.6, prev + 0.15))}
                className="w-10 h-10 bg-[#ffffff] rounded-lg border border-[#c4c5d5]/60 shadow-md flex items-center justify-center text-[#0b1c30] hover:bg-[#eff4ff] transition-colors"
                title="Zoom In"
              >
                <ZoomIn className="w-5 h-5" />
              </button>
              <button
                onClick={() => setMapZoom((prev) => Math.max(0.85, prev - 0.15))}
                className="w-10 h-10 bg-[#ffffff] rounded-lg border border-[#c4c5d5]/60 shadow-md flex items-center justify-center text-[#0b1c30] hover:bg-[#eff4ff] transition-colors"
                title="Zoom Out"
              >
                <ZoomOut className="w-5 h-5" />
              </button>
              <button
                onClick={() =>
                  setMapLayer((prev) => (prev === 'traffic' ? 'standard' : 'traffic'))
                }
                className={`w-10 h-10 rounded-lg border border-[#c4c5d5]/60 shadow-md flex items-center justify-center transition-colors mt-1 ${
                  mapLayer === 'traffic'
                    ? 'bg-[#1e40af] text-white'
                    : 'bg-[#ffffff] text-[#0b1c30] hover:bg-[#eff4ff]'
                }`}
                title="Toggle Traffic Layer"
              >
                <Layers className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </main>

      {/* Add New Vehicle Modal */}
      {showAddVehicleModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-[#c4c5d5]">
            <div className="flex justify-between items-center mb-5">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-lg bg-[#eff4ff] flex items-center justify-center text-[#00288e]">
                  <Bus className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-bold text-[#0b1c30]">Dispatch New Vehicle</h3>
              </div>
              <button
                onClick={() => setShowAddVehicleModal(false)}
                className="text-[#757684] hover:text-[#0b1c30]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddVehicle} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-[#0b1c30] mb-1">
                  Bus ID / Number
                </label>
                <input
                  type="text"
                  placeholder="e.g. 6204"
                  value={newBusNumber}
                  onChange={(e) => setNewBusNumber(e.target.value)}
                  className="w-full h-10 px-3 rounded-lg border border-[#c4c5d5] text-sm text-[#0b1c30] outline-none focus:border-[#1e40af]"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#0b1c30] mb-1">
                  Assigned Route
                </label>
                <input
                  type="text"
                  placeholder="e.g. NYC → BAL (Express)"
                  value={newBusRoute}
                  onChange={(e) => setNewBusRoute(e.target.value)}
                  className="w-full h-10 px-3 rounded-lg border border-[#c4c5d5] text-sm text-[#0b1c30] outline-none focus:border-[#1e40af]"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#0b1c30] mb-1">
                  Assigned Driver Name
                </label>
                <input
                  type="text"
                  placeholder="e.g. Marcus Vance"
                  value={newDriverName}
                  onChange={(e) => setNewDriverName(e.target.value)}
                  className="w-full h-10 px-3 rounded-lg border border-[#c4c5d5] text-sm text-[#0b1c30] outline-none focus:border-[#1e40af]"
                />
              </div>

              <div className="pt-2 flex gap-3">
                <button
                  type="button"
                  onClick={() => setShowAddVehicleModal(false)}
                  className="flex-1 py-2.5 border border-[#c4c5d5] text-sm font-semibold rounded-lg text-[#444653] hover:bg-[#eff4ff]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-[#1e40af] hover:bg-[#00288e] text-white text-sm font-semibold rounded-lg shadow-sm"
                >
                  Deploy Vehicle
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* View Route Status Modal */}
      {showRouteStatusModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-[#c4c5d5]">
            <div className="flex justify-between items-center mb-4">
              <div>
                <span className="text-xs font-semibold text-[#1e40af] uppercase tracking-wider">
                  Live Dispatch Telemetry
                </span>
                <h3 className="text-xl font-bold text-[#0b1c30]">
                  {selectedBus.number} Route Breakdown
                </h3>
              </div>
              <button
                onClick={() => setShowRouteStatusModal(false)}
                className="text-[#757684] hover:text-[#0b1c30]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Stops Timeline */}
            <div className="bg-[#eff4ff] p-4 rounded-xl border border-[#c4c5d5]/50 mb-5">
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-[#006c49] text-white flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                    ✓
                  </div>
                  <div>
                    <p className="text-sm font-bold text-[#0b1c30]">
                      {selectedBus.origin} - Central Terminal
                    </p>
                    <p className="text-xs text-[#006c49]">Departed on schedule (10:15 AM)</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-[#1e40af] text-white flex items-center justify-center text-xs font-bold shrink-0 mt-0.5 animate-pulse">
                    •
                  </div>
                  <div>
                    <p className="text-sm font-bold text-[#0b1c30]">
                      Midway Highway Corridor 95 (Mile Marker 142)
                    </p>
                    <p className="text-xs text-[#1e40af]">
                      Current Location • Speed: {selectedBus.speed} mph
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-[#c4c5d5] text-[#444653] flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                    3
                  </div>
                  <div>
                    <p className="text-sm font-bold text-[#0b1c30]">
                      {selectedBus.destination} - Main Hub
                    </p>
                    <p className="text-xs text-[#757684]">
                      Expected Arrival: {selectedBus.estArrival}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Dispatch Actions */}
            <div className="flex gap-3">
              <button
                onClick={() => {
                  alert(`Message sent to ${selectedBus.driverName} on ${selectedBus.number}`);
                }}
                className="flex-1 py-2.5 bg-[#eff4ff] text-[#00288e] border border-[#1e40af]/30 rounded-lg text-xs font-semibold hover:bg-[#dce9ff] transition-colors flex items-center justify-center gap-1.5"
              >
                <Send className="w-3.5 h-3.5" />
                Radio Dispatch
              </button>
              <button
                onClick={() => setShowRouteStatusModal(false)}
                className="flex-1 py-2.5 bg-[#00288e] text-white rounded-lg text-xs font-semibold hover:bg-[#00288e]/90 transition-colors"
              >
                Close View
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
